<?php $__env->startSection('content'); ?>

    <div class="container">


    <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

            <!-- First Blog Post -->

            <?php if($posts): ?>


                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <h2>
                <a href="#"><?php echo e($post->title); ?></a>
            </h2>
                    <p class="lead">
                by <?php echo e($post->user->name); ?></a>
            </p>
            <p><span class="glyphicon glyphicon-time"></span><?php echo e($post->created_at->diffForHumans()); ?></p>
            <hr>
            <img class="img-responsive" src="http://placehold.it/900x300" alt="">
            <hr>
            <p><?php echo str_limit($post->body,100); ?></p>
            <a class="btn btn-primary" href="/post/<?php echo e($post->slug); ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

            <hr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>




            <!-- Pagination-->

            <div class="row">

                <div class="col-sm-6 col-sm-offset-5">

                    <?php echo e($posts->render()); ?>


                </div>

            </div>



        </div>

        <!-- Blog Sidebar  -->
        <?php echo $__env->make('includes.front_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

     </div>
    <!-- /.row -->


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog-home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>