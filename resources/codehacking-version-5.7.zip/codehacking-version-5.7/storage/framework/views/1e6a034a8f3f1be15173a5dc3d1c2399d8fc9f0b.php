<?php $__env->startSection('content'); ?>


    <h1>Media</h1>

    <?php if($photos): ?>


        <form action="delete/media" method="post" class="form-inline">

            <?php echo e(csrf_field()); ?>


            <?php echo e(method_field('delete')); ?>



            <div class="form-group">
                <select name="checkBoxArray" id="" class="form-control">

                    <option value="">Delete</option>

                </select>
            </div>
            <div class="form-group">
               <input type="submit" name="delete_all" class="btn-primary">
            </div>


        <table class="table">
            <thead>
            <tr>
                <th><input type="checkbox" id="options"></th>
                <th>Id</th>
                <th>Name</th>
                <th>Created</th>
            </tr>
            </thead>
            <tbody>


            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><input class="checkBoxes" type="checkbox" name="checkBoxArray[]" value="<?php echo e($photo->id); ?>"></td>
                    <td><?php echo e($photo->id); ?></td>
                    <td><img height="50" src="<?php echo e($photo->file); ?>" alt=""></td>
                    <td><?php echo e($photo->created_at ? $photo->created_at : 'no date'); ?></td>
                    <td><input type="hidden" name="photo" value="<?php echo e($photo->id); ?>"></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        </form>

    <?php endif; ?>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


    <script>


        $(document).ready(function(){


            $('#options').click(function(){


                if(this.checked){

                    $('.checkBoxes').each(function(){


                        this.checked = true;

                    });

                }else {

                    $('.checkBoxes').each(function(){


                        this.checked = false;

                    });



                }






            });



        });


    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>