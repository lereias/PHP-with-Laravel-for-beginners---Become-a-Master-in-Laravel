@extends('layouts.admin')




@section('content')


    <h1>Admin</h1>



@stop