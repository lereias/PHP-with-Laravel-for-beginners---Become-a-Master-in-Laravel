


<?php if(Session::has('comment_message')): ?>

    <div class="alert alert-success col-sm-6">

       <p class="text-center"><?php echo e(session('comment_message')); ?></p>

    </div>




<?php endif; ?>