<?php $__env->startSection('content'); ?>


    <h1>Posts</h1>


    <table class="table">
       <thead>
         <tr>
             <th>Id</th>
             <th>Photo</th>
             <th>Title</th>
             <th>Owner</th>
             <th>Category</th>
             <th>Post link</th>
             <th>Comments</th>
             <th>Created at</th>
             <th>Update</th>
        </thead>
        <tbody>

        <?php if($posts): ?>


            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
              <td><?php echo e($post->id); ?></td>
              <td><img height="50" src="<?php echo e($post->photo ? $post->photo->file : 'http://placehold.it/400x400'); ?> " alt=""></td>
              <td><a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>"><?php echo e($post->title); ?></a></td>
              <td><?php echo e($post->user->name); ?></td>
              <td><?php echo e($post->category ? $post->category->name : 'Uncategorized'); ?></td>

              <td><a href="<?php echo e(route('home.post', $post->slug)); ?>">View Post</a></td>
              <td><a href="<?php echo e(route('admin.comments.show', $post->id)); ?>">View Comments</a></td>
              <td><?php echo e($post->created_at->diffForhumans()); ?></td>
              <td><?php echo e($post->updated_at->diffForhumans()); ?></td>

          </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

       </tbody>
     </table>



    <div class="row">
        <div class="col-sm-6 col-sm-offset-5">

            <?php echo e($posts->render()); ?>


        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>