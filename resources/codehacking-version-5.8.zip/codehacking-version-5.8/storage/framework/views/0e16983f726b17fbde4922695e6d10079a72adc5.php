<?php $__env->startSection('content'); ?>
    <h1 class="text-center">OOPS, it looks like you are in the wrong place</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>